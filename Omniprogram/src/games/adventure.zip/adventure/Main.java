package games.adventure;

/**
 * @author Jackson Murrell on Oct 25, 2015
 */
public class Main {

	/**
	 * @param args
	 * @return void
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
